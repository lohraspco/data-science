# Security-constrained unit-commitment

Security Constrained Unit Commitment (SCUC) is a mixed integer programming used for day-ahead planning in restructured electricity markets. 
