package investment;

public class InvestmentOptimization {

}
