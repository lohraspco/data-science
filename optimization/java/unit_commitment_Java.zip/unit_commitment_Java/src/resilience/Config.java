package resilience;

public class Config {

	public static boolean useMultiThread = true;
	public static int[] subsetCardinality = {0};

	public static double[] investmentScenariosAbsorption = {0 };
	public static double[] investmentScenariosTimeToRecovery = {0 };
	// since the investments may have different effects on absorption
	// and TTR we consider a cartesian of these situations
	public static double[][] investmentPool = createCartesianFromTwoSets(
			investmentScenariosTimeToRecovery, investmentScenariosAbsorption);

	public static enum scenarioSource {
		fromFile, powerSet, someSubsets
	}

	// String[] cases = { "bus118" };
	public static String[] cases = { "6bus" };

	private static double[][] createCartesianFromTwoSets(
			double[] investmentScenariosTimeToRecovery,
			double[] investmentScenariosAbsorption) {
		double[][] investmentPool = new double[investmentScenariosAbsorption.length
				* investmentScenariosTimeToRecovery.length][2];
		int iCounter = 0;
		for (int it1 = 0; it1 < investmentScenariosAbsorption.length; it1++)
			for (int it2 = 0; it2 < investmentScenariosTimeToRecovery.length; it2++) {
				investmentPool[iCounter][1] = investmentScenariosAbsorption[it1];
				investmentPool[iCounter][0] = investmentScenariosTimeToRecovery[it2];
				iCounter++;
			}

		return investmentPool;
	}

}
