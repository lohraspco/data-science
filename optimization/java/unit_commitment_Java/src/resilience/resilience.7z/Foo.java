package resilience;

import resilience.SCUCDataReader.Data;

public class Foo {
	public Foo(String [] caseNameArg, Data data, double[][] genBrokenScen, 
			double [][] lineBrokenScen,double[][] gasSupplyScen){
		
	}
}
