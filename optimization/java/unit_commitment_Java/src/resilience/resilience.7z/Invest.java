package resilience;

public class Invest {

}
