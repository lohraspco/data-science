This is the repository of the excercises that I worked on while following the course CS231n http://cs231n.stanford.edu/.
