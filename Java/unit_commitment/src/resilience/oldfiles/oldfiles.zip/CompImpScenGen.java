package resilience;

import java.util.HashSet;
import java.util.Set;

public class CompImpScenGen {

	public static void main(String[] args) {

		int j =3;
		System.out.print(1<<j);
//		Set<String> items = new HashSet<String>();
//		items.add("a1");
//		items.add("b2");
//		items.add("c3");
//
//		CompImpScenGen cis = new CompImpScenGen();
//		Set<Set<String>> results = cis.powerSet(items);
//		System.out.print(results);
	}

	public <T> Set<Set<T>> powerSet(Set<T> set) {
		@SuppressWarnings("unchecked")
		T[] elements = (T[]) set.toArray();
		Set<Set<T>> powerset = new HashSet<Set<T>>();
		final int totalElements = 1<<elements.length;
		for (int binarySet = 0; binarySet < totalElements; binarySet++) {
			Set<T> subset = new HashSet<T>();
			for (int bit = 0; bit < elements.length; bit++) {
				
				//(1<<bit) is a number with jth bit 1. so when we & them with the 
				//subset number we get which numbers are present in the subset
				int mask = 1 << bit;
				if ((binarySet & mask) != 0)
					subset.add(elements[bit]);
			}
			powerset.add(subset);
		}
		return powerset;

	}
}
