package resilience;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import inputOutput.WriteToFile;

import ilog.concert.IloException;
import ilog.cplex.IloCplex.UnknownObjectException;
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
public class Resilience extends JFrame{								
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main (String [] args) throws UnknownObjectException, IloException{
		
		JFrame jf = new JFrame("output");
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(500, 500);
		JPanel jp = new JPanel();
		
		TextArea jta = new TextArea(20,50);
		jp.add(jta);
		jf.add(jp);
		jf.setVisible(true);
		
		
		long startTime = System.currentTimeMillis();
		String [] cases = {"bus57_96h"};

		ArrayList<Thread> threads = new ArrayList<Thread>();
		for (int caseID=0;caseID<cases.length;caseID++){
			File folderPath = new File("Data"+File.separator+cases[caseID]);
			File [] genBrokenScenario =folderPath.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.toLowerCase().contains("gen");
				}
			});
			File gasFolder = new File(folderPath.getPath()+File.separator+"gasScenarios");
			File [] gasFiles = gasFolder.listFiles(new FilenameFilter() {

				@Override
				public boolean accept(File dir, String name) {
					// TODO Auto-generated method stub
					return name.toLowerCase().contains("gas");
				}
			});
			for (int i=0; i<genBrokenScenario.length;i++){
				if (genBrokenScenario[i].isFile()){
					for (int gasScenarioID = 0; gasScenarioID<gasFiles.length ; gasScenarioID++){
						if (gasFiles[gasScenarioID].isFile()){
							threads.add(new Thread(new UnitCommitment(cases[caseID], genBrokenScenario[i],
									gasFiles[gasScenarioID])));
						}
					}
				}
			}
		}
		int threadCounter=0;
		for (int t=0;t<threads.size();t++){
			threadCounter++;
			jta.append("thread " + threads.get(t).getName() + "started at" + System.currentTimeMillis()+"\n");
			threads.get(t).start();
			if (t>2){
				try {
					threads.get(t).join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		long totalRunTime = System.currentTimeMillis()-startTime;
		WriteToFile.writeLog("number of threads : " + threadCounter);
		WriteToFile.writeLog("elapsed time : " + totalRunTime/1000 +" seconds");
		/*	
		UnitCommitment uc2= new UnitCommitment("bus118");
		Thread tr2 = new Thread(uc2);
		tr2.start();
		double [] val = uc2.cplex.getValues(uc2.ls[0]);

		UnitCommitment uc1 = new UnitCommitment("bus6","Broken.txt");
		Thread tr1 = new Thread(uc1);
		tr1.start();*/
		
	}
	
}
